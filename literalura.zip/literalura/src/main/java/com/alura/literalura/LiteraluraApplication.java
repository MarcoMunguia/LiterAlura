package com.alura.literalura;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		ApiService apiService = new ApiService();
		BookDAO bookDAO = new BookDAO();

		Scanner scanner = new Scanner(System.in);
		int opcion;

		do {
			System.out.println("Bienvenido a LiterAlura. Elija una opción:");
			System.out.println("1- Buscar libros por título");
			System.out.println("2- Listar libros guardados");
			System.out.println("3- Salir");

			opcion = scanner.nextInt();
			scanner.nextLine(); // Consumir salto de línea

			switch (opcion) {
				case 1 -> {
					System.out.print("Ingrese el título del libro: ");
					String titulo = scanner.nextLine();
					var librosJson = apiService.buscarLibros(titulo);
					if (librosJson != null) {
						librosJson.forEach(libroJson -> {
							JsonObject libroObj = libroJson.getAsJsonObject();
							Book libro = new Book();
							libro.setTitle(libroObj.get("title").getAsString());
							libro.setLanguage(libroObj.getAsJsonArray("languages").get(0).getAsString());

							JsonObject autorObj = libroObj.getAsJsonArray("authors").get(0).getAsJsonObject();
							Author autor = new Author();
							autor.setName(autorObj.get("name").getAsString());
							libro.setAuthor(autor);

							bookDAO.guardarLibro(libro);
							System.out.println("Libro guardado: " + libro.getTitle());
						});
					}
				}
				case 2 -> {
					System.out.println("Listando libros guardados...");
					// Aquí listaríamos libros usando una consulta en la base de datos.
				}
			}
		} while (opcion != 3);
	}
}
